plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "studio.syntax.fal"
    compileSdk = 35

    defaultConfig {
        applicationId = "studio.syntax.fal"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.1.0-beta"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        release {
            // Beta distribution only: signed with Android's debug certificate so it can be installed.
            // Replace with a private release keystore before public production distribution.
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }
}
