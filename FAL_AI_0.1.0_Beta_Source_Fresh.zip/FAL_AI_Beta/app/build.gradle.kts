plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "studio.syntax.fal"
    compileSdk = 35
    defaultConfig {
        applicationId = "studio.syntax.fal"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-beta"
    }
}
