package studio.syntax.fal

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

class FloatingService:Service() {
    private lateinit var wm:WindowManager
    private var bubble:View?=null
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate() { super.onCreate(); running=true; wm=getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
    override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
    private fun showBubble() {
        val b=TextView(this).apply { text="F"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(95,100,115)); elevation=12f }
        val p=WindowManager.LayoutParams(58,58,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=240 }
        b.setOnTouchListener(object:View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v:View,e:android.view.MotionEvent):Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=(ox+sx-e.rawX).toInt(); p.y=(oy+e.rawY-sy).toInt(); wm.updateViewLayout(b,p); return true }
                    MotionEvent.ACTION_UP -> { if(kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) showKeys(); return true }
                }; return false
            }
        })
        bubble=b; wm.addView(b,p)
    }
    private fun showKeys() {
        val entries=Vault.all(this)
        val box=LinearLayout(this).apply { orientation=1; setPadding(18,12,18,12); setBackgroundColor(Color.rgb(17,20,28)) }
        val head=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text="FAL VAULT"; textSize=18f; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        head.addView(Button(this).apply { text="×"; setOnClickListener { try { wm.removeView(box) } catch(_:Exception){} } })
        box.addView(head)
        if(entries.isEmpty()) box.addView(TextView(this).apply { text="No saved keys"; setTextColor(Color.LTGRAY) })
        entries.forEach { e -> box.addView(Button(this).apply { text="${e.service}  ·  ${e.name}"; setOnClickListener {
            val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("FAL credential",e.value))
            Toast.makeText(this@FloatingService,"Copied ${e.name}",Toast.LENGTH_SHORT).show()
        }}) }
        val p=WindowManager.LayoutParams(300,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=310 }
        wm.addView(box,p)
    }
    override fun onDestroy() { running=false; bubble?.let { try { wm.removeView(it) } catch(_:Exception){} }; bubble=null; super.onDestroy() }
    companion object { @Volatile var running=false }
}
