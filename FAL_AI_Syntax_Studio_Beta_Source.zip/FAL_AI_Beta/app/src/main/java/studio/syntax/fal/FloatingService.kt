package studio.syntax.fal

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context

class FloatingService:Service() {
    private lateinit var wm:WindowManager
    private var bubble:View?=null
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate() { super.onCreate(); running=true; wm=getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
    override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
    private fun showBubble() {
        val b=TextView(this).apply { text="S"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(95,100,115)); elevation=12f }
        val p=WindowManager.LayoutParams(58,58,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=240 }
        b.setOnTouchListener(object:View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v:View,e:android.view.MotionEvent):Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=(ox+sx-e.rawX).toInt(); p.y=(oy+e.rawY-sy).toInt(); wm.updateViewLayout(b,p); return true }
                    MotionEvent.ACTION_UP -> { if(kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) showKeys(); return true }
                }; return false
            }
        })
        bubble=b; wm.addView(b,p)
    }
    private fun showKeys() {
        val entries=Vault.all(this)
        val box=LinearLayout(this).apply { orientation=1; setPadding(18,12,18,12); setBackgroundColor(Color.rgb(17,20,28)) }
        val head=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text="SYNTAX STUDIO"; textSize=16f; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        head.addView(Button(this).apply { text="×"; setOnClickListener { try { wm.removeView(box) } catch(_:Exception){} } })
        box.addView(head)
        box.addView(TextView(this).apply { text="FAL AI  •  BETA 0.1.0\nTap a credential name 3 times to copy it."; textSize=12f; setTextColor(Color.LTGRAY); setPadding(4,8,4,12) })
        if(entries.isEmpty()) box.addView(TextView(this).apply { text="No saved keys"; setTextColor(Color.LTGRAY) })
        entries.forEach { e ->
            var taps = 0
            var lastTap = 0L
            box.addView(Button(this).apply {
                text="${e.service}  ·  ${e.name}  (0/3)"
                setOnClickListener {
                    val now = android.os.SystemClock.elapsedRealtime()
                    taps = if (now - lastTap <= 1200L) taps + 1 else 1
                    lastTap = now
                    text = "${e.service}  ·  ${e.name}  ($taps/3)"
                    if (taps >= 3) {
                        val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("FAL credential",e.value))
                        Toast.makeText(this@FloatingService,"${e.name} copied",Toast.LENGTH_SHORT).show()
                        taps = 0
                        text = "${e.service}  ·  ${e.name}  (0/3)"
                    }
                }
            })
        }
        val p=WindowManager.LayoutParams(300,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=310 }
        wm.addView(box,p)
    }
    override fun onDestroy() { running=false; bubble?.let { try { wm.removeView(it) } catch(_:Exception){} }; bubble=null; super.onDestroy() }
    companion object { @Volatile var running=false }
}
