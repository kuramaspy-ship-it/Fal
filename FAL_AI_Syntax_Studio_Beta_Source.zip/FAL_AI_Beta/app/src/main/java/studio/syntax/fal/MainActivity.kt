package studio.syntax.fal

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray

class MainActivity:Activity() {
    private val bg=Color.rgb(10,12,18); private val silver=Color.rgb(205,210,220)
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); render() }
    private fun label(t:String,size:Float=15f):TextView = TextView(this).apply { text=t; textSize=size; setTextColor(silver); setPadding(14,10,14,10) }
    private fun button(t:String, action:()->Unit)=Button(this).apply { text=t; setOnClickListener { action() } }
    private fun render() {
        val root=LinearLayout(this).apply { orientation=1; setPadding(18,22,18,18); setBackgroundColor(bg) }
        root.addView(label("SYNTAX STUDIO",13f)); root.addView(label("FAL AI",32f))
        root.addView(label("FLOATING API LOCKER  •  BETA 0.1.0",12f))
        val toggle=Switch(this).apply { text="Floating Mode"; setTextColor(silver); isChecked=FloatingService.running
            setOnCheckedChangeListener { _,on ->
                if(on && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    isChecked=false
                } else if(on) startService(Intent(this@MainActivity,FloatingService::class.java))
                else stopService(Intent(this@MainActivity,FloatingService::class.java))
            }
        }; root.addView(toggle)
        root.addView(label("YOUR CREDENTIALS",18f))
        val list=Vault.all(this)
        if(list.isEmpty()) root.addView(label("No credentials yet. Add one or import a .key.fal file."))
        list.forEachIndexed { i,e ->
            val row=LinearLayout(this).apply { orientation=0; gravity=Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text="${e.service}  ·  ${e.name}"; setTextColor(silver); textSize=14f; layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
            row.addView(Button(this).apply { text="COPY"; setOnClickListener {
                val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("FAL credential",e.value))
                Toast.makeText(this@MainActivity,"Copied ${e.name}",Toast.LENGTH_SHORT).show()
            }})
            root.addView(row)
        }
        root.addView(button("＋  ADD CREDENTIAL") { addDialog() })
        root.addView(button("IMPORT .KEY.FAL") { pickFile() })
        root.addView(button("REFRESH") { render() })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun addDialog() {
        val box=LinearLayout(this).apply { orientation=1; setPadding(20,10,20,10) }
        val service=EditText(this).apply { hint="Service (e.g. Paystack)" }
        val name=EditText(this).apply { hint="Credential name (e.g. Secret Key)" }
        val value=EditText(this).apply { hint="Secret value"; inputType=129 }
        box.addView(service); box.addView(name); box.addView(value)
        AlertDialogBuilder.show(this,box) {
            if(service.text.isNotBlank() && name.text.isNotBlank() && value.text.isNotBlank()) {
                Vault.add(this,Entry(service.text.toString(),name.text.toString(),value.text.toString()))
                render()
            }
        }
    }
    private fun pickFile() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        type="application/json"; addCategory(Intent.CATEGORY_OPENABLE)
    },44) }
    @Deprecated("Deprecated Android callback retained for beta compatibility")
    override fun onActivityResult(req:Int,res:Int,data:Intent?) { super.onActivityResult(req,res,data)
        if(req==44 && res==RESULT_OK) try {
            val text=contentResolver.openInputStream(data!!.data!!)!!.bufferedReader().readText()
            val count=Vault.importJson(this,text); Toast.makeText(this,"Imported $count credentials",Toast.LENGTH_LONG).show(); render()
        } catch(e:Exception) { Toast.makeText(this,"Import failed: ${e.message}",Toast.LENGTH_LONG).show() }
    }
}
object AlertDialogBuilder {
    fun show(a:Activity,v:View,save:()->Unit) {
        android.app.AlertDialog.Builder(a).setTitle("Add credential").setView(v)
            .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_-> save() }.show()
    }
}
