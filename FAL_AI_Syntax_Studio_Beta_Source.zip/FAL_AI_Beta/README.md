# FAL AI — Syntax Studio Beta

**Version:** 0.1.0-beta  
**Brand:** Syntax Studio

## Beta features
- Syntax Studio branded app and floating bubble.
- Movable floating bubble; tap it to open the credential vault.
- Tap a credential row three times (within 1.2 seconds between taps) to copy its value.
- Floating Mode can be started/stopped from the main app.
- Credential values are encrypted locally with AES-GCM using Android Keystore.
- Add credentials manually or import a `.key.fal` JSON file.

## Build output
The GitHub workflow builds the `release` variant (`assembleRelease`), not the debug variant. For convenient beta installation, this release variant is signed with the standard Android debug certificate. It is **not production-signed**. Keep the signing key private and use a dedicated private release keystore before public production distribution.

## Security notes
- This beta has not been independently security-audited.
- `.key.fal` import is plain JSON. Do not share files containing real API secrets.
- No AI assistant, cloud sync, encrypted export, biometric lock, or clipboard auto-clear.
- Test with disposable credentials before storing real secrets.
