package studio.syntax.fal

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import org.json.JSONArray
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Entry(val service:String, val name:String, val value:String, val type:String="secret")

object Vault {
    private const val PREF="fal_vault"
    private const val ALIAS="fal_aes_key"
    private const val DATA="entries"

    private fun key(): SecretKey {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS,null) as? SecretKey)?.let { return it }
        val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return kg.generateKey()
    }
    private fun seal(s:String):String {
        val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key())
        val blob=c.iv+c.doFinal(s.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(blob,Base64.NO_WRAP)
    }
    private fun open(s:String):String {
        val blob=Base64.decode(s,Base64.NO_WRAP); val iv=blob.copyOfRange(0,12)
        val body=blob.copyOfRange(12,blob.size); val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))
        return String(c.doFinal(body),Charsets.UTF_8)
    }
    fun all(ctx:Context):MutableList<Entry> {
        val raw=ctx.getSharedPreferences(PREF,0).getString(DATA,"[]") ?: "[]"
        val arr=JSONArray(raw); val out=mutableListOf<Entry>()
        for(i in 0 until arr.length()) try {
            val o=arr.getJSONObject(i); out.add(Entry(o.getString("service"),o.getString("name"),open(o.getString("value")),o.optString("type","secret")))
        } catch(_:Exception) {}
        return out
    }
    fun save(ctx:Context, entries:List<Entry>) {
        val arr=JSONArray()
        entries.forEach { e -> arr.put(JSONObject().put("service",e.service).put("name",e.name).put("type",e.type).put("value",seal(e.value))) }
        ctx.getSharedPreferences(PREF,0).edit().putString(DATA,arr.toString()).apply()
    }
    fun add(ctx:Context,e:Entry) { val list=all(ctx); list.add(e); save(ctx,list) }
    fun importJson(ctx:Context, text:String):Int {
        val root=JSONObject(text)
        require(root.optString("format")=="FAL") { "Not a FAL file" }
        val service=root.optString("service","Imported")
        val arr=root.getJSONArray("credentials"); val list=all(ctx)
        for(i in 0 until arr.length()) {
            val o=arr.getJSONObject(i); list.add(Entry(service,o.getString("name"),o.getString("value"),o.optString("type","secret")))
        }
        save(ctx,list); return arr.length()
    }
}
