# FAL AI — Floating API Locker
**Version:** 0.1.0-beta  
**Brand:** Syntax Studio

Android beta source project.

## Features in this beta
- Floating overlay bubble, movable on screen.
- Tap the bubble to show saved credentials.
- Tap a credential to copy it to the clipboard.
- Floating Mode can be started/stopped from the main app.
- Credential values are encrypted locally with AES-GCM using Android Keystore.
- Add credentials manually or import a `.key.fal` JSON file.

## Important limitations
- Beta software; not independently security-audited.
- `.key.fal` import is plain JSON. Do not share files containing real API secrets.
- No AI assistant, cloud sync, encrypted export, biometric lock, clipboard auto-clear, or production signing in this beta.
- Test first with disposable credentials.
